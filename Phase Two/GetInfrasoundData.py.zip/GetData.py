import obspy
import matplotlib.pyplot as plt
import numpy as np
from obspy import read, read_inventory
from obspy.clients.fdsn import Client
from obspy import UTCDateTime
from math import radians, sin, cos, sqrt, atan2

#Given the coordinates and a window of time, this code search for the closest stations with infrasound data
#available, it print the list of stations and fetch the data in sequence until gathers max Ns number of data.
#Code made by T. Espinosa-Ortega contact teortega@ntu.edu.sg

##########INPUTS##################
#Event Coordinates, time/ INPUT WILL BE GIVEN BY VONA ALERTS
lat0=-0.38034
lon0=100.474424
starttime1 =UTCDateTime("2025-05-05T14:30:00")# UTCDateTime.now() - 2* 3600  # 2 hours ago
endtime1 = UTCDateTime("2025-05-05T16:30:00") # UTCDateTime.now()
Ns=3 #number max of stream to fetch
##########END INPUTS###############

############     FUNCTIONS  ###############
#############definimos the lenght of a degree of longitud (m) and latitude
a = 6378137 #earth radio for elipsoid
b = 6356752.3142 #earth radio for elipsoid
e1 = np.sqrt((a*a - b*b)/(a*a))
def LoD(t):
    return (np.pi*a/180)*np.cos(np.arctan(b*np.tan(t)/a))

def LaD(t):
    return a*np.pi*(1-e1*e1)/(180*np.power((1-e1*e1*np.sin(t)*np.sin(t)),3/2))

############Distance between 2 set of coordinates
def haversine(lat1, lon1, lat2, lon2):
    # Convert degrees to radians
    lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])
    # Haversine formula
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
    c = 2 * atan2(sqrt(a), sqrt(1-a))
    radius_earth = 6371  # Earth radius in km
    return radius_earth * c
############ END  FUNCTIONS  ###############


#Fetch station from IRIS
client = Client("IRIS")
channels="BDF,LDF" #Infrasound
LRat=3000*1000 #search station ratio in m (3mil km)
min_lat, max_lat=lat0-LRat/LaD(lat0), lat0+LRat/LaD(lat0) # Latitude range
min_lon, max_lon=lon0-LRat/LoD(lon0), lon0+LRat/LoD(lon0) # Longitude range 

# Fetch station metadata
inventory = client.get_stations(
    starttime= starttime1,
    endtime=endtime1,
    minlatitude=min_lat,
    maxlatitude=max_lat,
    minlongitude=min_lon,
    maxlongitude=max_lon,
    channel=channels,
    level="station"
)

# Calculate distances and store stations
stations = []
for net in inventory:
    for sta in net:
        # Haversine distance 
        dist=haversine(lat0,lon0,sta.latitude,sta.longitude)  # Distance km
        stations.append({
            "network": net.code,
            "station": sta.code,
            "latitude": sta.latitude,
            "longitude": sta.longitude,
            "distance_km": dist
        })


# Sort by distance 
closest_stations = sorted(stations, key=lambda x: x["distance_km"])

print("Closest stations:")
for sta in closest_stations:
    print(f"{sta['network']}.{sta['station']} ({sta['distance_km']:.2f} km)")

###Fetch data
# Fetch data for Ns closest stations
streams = []
for sta in closest_stations:
    try:
        st = client.get_waveforms(
            network=sta["network"],
            station=sta["station"],
            location="*",  # Wildcard for all location codes
            channel="BDF,LDF",  # Infrasound channels
            starttime=starttime1,
            endtime=endtime1
        )
        streams.append(st)
        print(f"Fetched data for {sta['network']}.{sta['station']}")
        if len(streams)==Ns:
            break    
    except Exception as e:
        print(f"Failed to fetch data for {sta['network']}.{sta['station']}: {e}")

#Plot data
if streams:
    fig, axes = plt.subplots(len(streams), 1, figsize=(12, 7), sharex=True)
    for i, st in enumerate(streams):
        axes[i].plot(st[0].times("matplotlib"), st[0].data, label=f"{st[0].id}")
        axes[i].legend()
        axes[i].set_ylabel("Amplitude")
        axes[i].xaxis_date()
    axes[-1].set_xlabel("Time")
    plt.suptitle(f"Infrasound Data from Closest Stations (Near {lat0}°, {lon0}°)")
    plt.show()
else:
    print("No data to plot.")

